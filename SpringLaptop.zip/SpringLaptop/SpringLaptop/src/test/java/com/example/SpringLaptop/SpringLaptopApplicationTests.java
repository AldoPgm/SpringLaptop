package com.example.SpringLaptop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLaptopApplicationTests {

	@Test
	void contextLoads() {
	}

}
